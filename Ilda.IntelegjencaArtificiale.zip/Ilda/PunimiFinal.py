#1
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report
from sklearn import metrics
import matplotlib.pyplot as plt
import seaborn as sns
#2
train_data = pd.read_csv("dataset.csv", encoding='ISO-8859-1')
train_data = train_data.fillna('')
#3
x = np.array(train_data["Text"])
y = np.array(train_data["language"])
#4
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=0)
#5
cv = CountVectorizer()
X_train = cv.fit_transform(x_train)
X_test = cv.transform(x_test)
print(X_train)
print(X_test)
#6
model = MultinomialNB()
model.fit(X_train, y_train)
#7
y_pred = model.predict(X_test)
#8
user = input("Jepni nje tekst: ")
data = cv.transform([user]).toarray()
output = model.predict(data)
print("Prediction:", output)
#9
target_names = list(reversed(train_data['language'].unique()))
print(classification_report(y_test, y_pred, target_names=target_names))

#10
confusion_matrix = metrics.confusion_matrix(y_test, y_pred)
#print(confusion_matrix)
#confusion_matrix NUK E KEMI PRINTUAR PER ARSYE ESHTE SHUME E GJATE 
#11
sns.heatmap(confusion_matrix, annot=True, fmt='d')

labels = train_data['language'].unique()
num_labels = len(labels)
plt.xticks(range(num_labels), labels[::-1], rotation=90)
plt.yticks(range(num_labels), labels[::-1], rotation=0)
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.title("Confusion Matrix")
plt.show()



#12
# Calculate probabilities for each class
probs = model.predict_proba(X_test)

# Plot ROC curve for each class
plt.figure(figsize=(8, 6))
for i in range(num_labels):
    fpr, tpr, thresholds = metrics.roc_curve(y_test, probs[:, i], pos_label=labels[i])
    plt.plot(fpr, tpr, label=f'ROC Curve ({labels[i]})')

plt.plot([0, 1], [0, 1], linestyle='--', color='gray', label='Random')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend()
plt.show()


#13
# Convert y_test to a pandas Series for countplot
y_test_series = pd.Series(y_test)

# Plot bar chart for the distribution of classes in the test set
# Sort the labels in the pandas Series before plotting
y_test_series.value_counts().loc[labels[::-1]].plot(kind='bar', figsize=(10, 6))
plt.xlabel('Language')
plt.ylabel('Count')
plt.title('Class Distribution in Test Set')
plt.show()

